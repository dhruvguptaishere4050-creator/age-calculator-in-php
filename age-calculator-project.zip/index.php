<?php
declare(strict_types=1);

$dateOfBirth = '';
$result = null;
$error = '';
$today = new DateTimeImmutable('today');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dateOfBirth = trim((string) ($_POST['date_of_birth'] ?? ''));
    $birthDate = DateTimeImmutable::createFromFormat('!Y-m-d', $dateOfBirth);
    $dateErrors = DateTimeImmutable::getLastErrors();
    $hasDateErrors = $dateErrors !== false
        && ($dateErrors['warning_count'] > 0 || $dateErrors['error_count'] > 0);

    if ($dateOfBirth === '') {
        $error = 'Choose a date of birth to continue.';
    } elseif ($birthDate === false || $hasDateErrors || $birthDate->format('Y-m-d') !== $dateOfBirth) {
        $error = 'Enter a valid date of birth.';
    } elseif ($birthDate > $today) {
        $error = 'A date of birth cannot be in the future.';
    } else {
        $difference = $birthDate->diff($today);
        $result = [
            'years' => $difference->y,
            'months' => $difference->m,
            'days' => $difference->d,
        ];
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#1e312c">
    <title>Age Calculator</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Newsreader:opsz,wght@6..72,400;6..72,500;6..72,600&display=swap" rel="stylesheet">
    <style>
        :root { background: #f6f5f0; color: #1e312c; font-family: "DM Mono", ui-monospace, SFMono-Regular, Consolas, monospace; }
        * { box-sizing: border-box; }
        body { align-items: center; display: flex; justify-content: center; margin: 0; min-height: 100svh; padding: 28px; }
        .calculator { border-top: 2px solid #1e312c; max-width: 530px; padding: clamp(26px, 6vw, 52px) 0; width: 100%; }
        .eyebrow { color: #5d706a; font-size: .69rem; letter-spacing: .12em; margin: 0 0 28px; text-transform: uppercase; }
        h1 { font-family: "Newsreader", Georgia, serif; font-size: clamp(3.25rem, 13vw, 5.6rem); font-weight: 500; letter-spacing: -.075em; line-height: .83; margin: 0; }
        .intro { color: #52605c; font-size: .79rem; line-height: 1.8; margin: 30px 0 38px; max-width: 44ch; }
        form { display: grid; gap: 11px; }
        label { font-size: .72rem; letter-spacing: .04em; }
        input { appearance: none; background: transparent; border: 1px solid #aeb7b2; border-radius: 0; color: #1e312c; font: inherit; font-size: .85rem; min-height: 52px; outline: none; padding: 0 14px; transition: border-color .18s, background .18s; width: 100%; }
        input:focus { background: #fff; border-color: #1e312c; }
        button { background: #1e312c; border: 1px solid #1e312c; border-radius: 0; color: #fff; cursor: pointer; font: inherit; font-size: .76rem; letter-spacing: .04em; margin-top: 9px; min-height: 52px; transition: background .18s, color .18s; width: 100%; }
        button:hover { background: transparent; color: #1e312c; }
        button:focus-visible { outline: 2px solid #1e312c; outline-offset: 3px; }
        .notice { font-size: .78rem; line-height: 1.7; margin: 30px 0 0; padding-top: 20px; }
        .error { border-top: 1px solid #b54f47; color: #9a332b; }
        .result { border-top: 1px solid #1e312c; text-align: left; }
        .result-label { color: #5d706a; font-size: .67rem; letter-spacing: .11em; margin: 0 0 15px; text-transform: uppercase; }
        .years { font-family: "Newsreader", Georgia, serif; font-size: clamp(4.5rem, 20vw, 7.5rem); font-weight: 500; letter-spacing: -.09em; line-height: .75; margin: 0; }
        .years span { font-family: "DM Mono", ui-monospace, monospace; font-size: .13em; letter-spacing: .02em; margin-left: 7px; }
        .breakdown { color: #5d706a; font-size: .72rem; margin: 23px 0 0; }
        @media (prefers-reduced-motion: reduce) { *, *::before, *::after { scroll-behavior: auto !important; transition-duration: .01ms !important; } }
    </style>
</head>
<body>
    <main class="calculator">
        <p class="eyebrow">Age calculator</p>
        <h1>How long<br>have you been<br>here?</h1>
        <p class="intro">Enter a date of birth. The calculation is based on today and shows completed years.</p>

        <form method="post" action="" novalidate>
            <label for="date_of_birth">Date of birth</label>
            <div class="field">
                <input id="date_of_birth" name="date_of_birth" type="date" value="<?= htmlspecialchars($dateOfBirth, ENT_QUOTES, 'UTF-8') ?>" max="<?= $today->format('Y-m-d') ?>" required aria-describedby="date-help">
            </div>
            <button type="submit">Calculate age</button>
        </form>

        <?php if ($error !== ''): ?>
            <p id="date-help" class="notice error" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
        <?php elseif ($result !== null): ?>
            <section class="notice result" aria-live="polite" aria-label="Age result">
                <p class="result-label">Current age</p>
                <p class="years"><?= $result['years'] ?> <span><?= $result['years'] === 1 ? 'year' : 'years' ?></span></p>
                <p class="breakdown">That is <?= $result['months'] ?> months and <?= $result['days'] ?> days beyond their last birthday.</p>
            </section>
        <?php endif; ?>
    </main>
</body>
</html>
